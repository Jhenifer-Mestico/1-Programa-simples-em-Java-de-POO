/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeiraaulapob;

import Animais.Gato;
import java.util.Date;

/**
 *
 * @author Jhenifer
 */
public class PrimeiraAulaPOB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Olá mundo");
        
        Gato objGato = new Gato();
        System.out.println("Hoje é" + new Date());
    }
    
}
